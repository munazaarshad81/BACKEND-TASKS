const express = require('express')
const { 
    getStudents, 
    getStudentByID, 
    createStudent, 
    updateStudent,
    deleteStudent
} = require('../controllers/stundentController')

//router object 
const router = express.Router()

//routes

//GET all Students list || GET
router.get('/getall',getStudents);

//GET Student by ID 
router.get('/get/:id', getStudentByID )

//CREATE Student || POST
router.post('/create', createStudent)

//UPDATE Student || PUT
router.put('/update/:id', updateStudent)

//DELETE Student || DELETE
router.delete('/delete/:id', deleteStudent)

module.exports = router
