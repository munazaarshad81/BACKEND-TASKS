const db = require("../config/db");

//GET all Students list
const getStudents  = async (req,res) => {
    try {
        const [Data] = await db.query('SELECT * FROM students')
        if (!Data) {
            return res.status(404).send({
                success:false,
                message:'No Records Found'
            });
        }
        res.status(200).send({
            Success:true,
            Message:'All Students Records',
            Total_Students: [Data][0].length,
            Data,
        });
    }
     catch (error) {
        console.log(error)
        res.ststus(500).send({
            success:false,
            messag:'Error in Get All Student API',
            error,
        });
    }
};


//GET Student bt ID
const getStudentByID = async (req,res) => {
    try {
        const studentId = req.params.id
        if (!studentId) {
            return res.status(404).send({
                Success:false,
                message:'Invalid OR Provide Student ID'
            })
        }
        //  const data = await db.query('SELECT * FROM students WHERE id = '+studentId)
        const [data] = await db.query('SELECT * FROM students WHERE id=?',[studentId])
            if (!data) {
                return res.status(404).send({
                    success:false,
                    message:'NO Records Found'
                })
            }
            res.status(200).send({
                Success:true,
                StudentDetails: [data][0],
            })
    }
        catch(error) {
        console.log(error)
        res.status(500).send({
            success:false,
            message:'Error in Get  Student by ID API',
            error
        })
    }
};
    
// CREATE Student 
const createStudent = async (req,res) => {
    try {
        const {Name,Roll_No,Department,Age} = req.body
        if(!Name || !Roll_No || !Department || !Age){
            return res.status(500).send({
                success:false,
                message:'Please provide all fields'
            })
        }
        const [data] = await db.query('INSERT INTO students (Name,Roll_No,Department,Age) VALUES(? , ? , ? , ?)', 
            [Name,Roll_No,Department,Age])
        if (!data) {
            return res.status(404).send({
                success:false,
                message:'Error in INSERT Query'
            })
        }
        res.status(201).send({
            Success:true,
            Message:"New Student Record Created Successfully",
        })
    } catch (error) {
        console.log(error)
        res.status(500).send({
            success:false,
            message:'Error in Create Student API',
            error
        })
        
    }
};

// UPDATE Student
const updateStudent = async (req,res) => {
    try {
        const studentId = req.params.id
        if (!studentId) {
            return res.status(404).send({
                success:false,
                message:'Invalid ID or Provide ID'
            })
        }
        const {Name,Roll_No,Department,Age} = req.body
        const data = await db.query('UPDATE students SET Name = ? ,Roll_No = ? ,Department = ? ,Age = ? WHERE id = ?',[Name,Roll_No,Department,Age,studentId])
        if (!data) {
            return res.status(500).send({
                successs:false,
                message:'Error In UPDATE Data'
            })
        }
        res.status(200).send({
            Success:true,
            Message:'Student Details Updated Successfully',

        })
    } catch (error) {
        console.log(error)
        res.status(500).send({
            success:false,
            message:'Error In UPDATE Student API',
            error
        })
        
    }
};

//DELETE Student
const deleteStudent = async (req,res) => {
    try {
        const studentId = req.params.id
        if (!studentId) {
            return res.status(404).send({
                success:false,
                message:'Please Provide Student ID OR Valid Student ID',
            })
        }
        await db.query('DELETE FROM students WHERE id = ?', [studentId])
        res.status(200).send({
            Success:true,
            Message:'Student Record DELETED Successfully',
        });
    } catch (error) {
        console.log(error)
        res.status(500).send({
            success:false,
            message:'Error in DELETE Student API',
            error
        })
        
    }
}

module.exports = { getStudents, getStudentByID, createStudent, updateStudent, deleteStudent};