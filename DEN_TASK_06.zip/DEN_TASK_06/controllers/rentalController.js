const Rental = require('../models/Rental');

// Create a rental
exports.createRental = async (req, res) => {
  try {
    const newRental = await Rental.create(req.body);
    res.status(201).json(newRental);
  } catch (error) {
    res.status(500).json({ error: 'Unable to create rental' });
  }
};

// Get a rental by ID
exports.getRental = async (req, res) => {
  try {
    const rental = await Rental.findByPk(req.params.id);
    if (!rental) {
      return res.status(404).json({ error: 'Rental not found' });
    }
    res.json(rental);
  } catch (error) {
    res.status(500).json({ error: 'Unable to fetch rental' });
  }
};

// Update a rental
exports.updateRental = async (req, res) => {
  try {
    const rental = await Rental.findByPk(req.params.id);
    if (!rental) {
      return res.status(404).json({ error: 'Rental not found' });
    }
    await rental.update(req.body);
    res.json(rental);
  } catch (error) {
    res.status(500).json({ error: 'Unable to update rental' });
  }
};

// Delete a rental
exports.deleteRental = async (req, res) => {
  try {
    const rental = await Rental.findByPk(req.params.id);
    if (!rental) {
      return res.status(404).json({ error: 'Rental not found' });
    }
    await rental.destroy();
    res.status(204).send();
  } catch (error) {
    res.status(500).json({ error: 'Unable to delete rental' });
  }
};

// Get all rentals
exports.getAllRentals = async (req, res) => {
  try {
    const rentals = await Rental.findAll();
    res.json(rentals);
  } catch (error) {
    res.status(500).json({ error: 'Unable to fetch rentals' });
  }
};
