const express = require('express');
const router = express.Router();
const propertyController = require('../controllers/propertyController');

// Property routes
router.post('/create', propertyController.createProperty);
router.get('/:id', propertyController.getProperty);
router.put('/:id', propertyController.updateProperty);
router.delete('/:id', propertyController.deleteProperty);
router.get('/', propertyController.getAllProperties);

module.exports = router;
