const express = require('express');
const router = express.Router();
const rentalController = require('../controllers/rentalController');

// Rental routes
router.post('/create', rentalController.createRental);
router.get('/:id', rentalController.getRental);
router.put('/:id', rentalController.updateRental);
router.delete('/:id', rentalController.deleteRental);
router.get('/', rentalController.getAllRentals);

module.exports = router;
