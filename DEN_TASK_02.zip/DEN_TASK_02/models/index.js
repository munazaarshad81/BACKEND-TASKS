const Sequelize = require('sequelize');
const dbConfig = require('../config/db.config.js');

const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
  host: dbConfig.HOST,
  dialect: dbConfig.dialect,
});

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.User = require('./user.js')(sequelize, Sequelize.DataTypes);
db.Post = require('./post.js')(sequelize, Sequelize.DataTypes);
db.Comment = require('./comment.js')(sequelize, Sequelize.DataTypes);

// Relationships
db.User.hasMany(db.Post, { as: 'posts', foreignKey: 'author_id' });
db.Post.belongsTo(db.User, { as: 'user', foreignKey: 'user_id' });

db.Post.hasMany(db.Comment, { as: 'comments', foreignKey: 'post_id' });
db.Comment.belongsTo(db.Post, { as: 'post', foreignKey: 'post_id' });

db.User.hasMany(db.Comment, { as: 'comments', foreignKey: 'user_id' });
db.Comment.belongsTo(db.User, { as: 'user', foreignKey: 'user_id' });

module.exports = db;
