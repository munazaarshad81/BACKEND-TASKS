const { Playlist, Song } = require('../models/User');

exports.createPlaylist = async (req, res) => {
  const { name } = req.body;
  const playlist = await Playlist.create({ name, user_id: req.user.id });
  res.json(playlist);
};

exports.updatePlaylist = async (req, res) => {
  const { song_ids } = req.body;
  const playlist = await Playlist.findByPk(req.params.id);

  if (!playlist) {
    return res.status(404).json({ message: 'Playlist not found' });
  }

  await playlist.setSongs(song_ids);  // Associating songs with the playlist
  res.json(playlist);
};
