const express = require('express');
const { getAllSongs, getGenres } = require('../controllers/songController');
const router = express.Router();

router.get('/songs', getAllSongs);
router.get('/genres', getGenres);

module.exports = router;
